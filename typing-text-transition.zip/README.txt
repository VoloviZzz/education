A Pen created at CodePen.io. You can find this one at https://codepen.io/rachsmith/pen/oGEMbz.

 having a bit of fun with GSAP and SVG.

The rainbow color scheme being used here I first saw on https://githubuniverse.com